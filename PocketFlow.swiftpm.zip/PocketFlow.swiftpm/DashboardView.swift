
import SwiftUI
import Charts

// MARK: - 3. DASHBOARD VIEW
struct DashboardView: View {
    @Environment(AppDataStore.self) private var store
    @State private var timeRange = "7 Days"
    let timeRanges = ["1 Day", "7 Days", "30 Days", "12 Months"]
    
    @State private var selectedCategoryForNav: String? = nil
    @State private var showContriDetail = false
    @State private var rawSelection: Double? = nil
    
    // NEW: Animation & Safety States
    @State private var poppedCategory: String? = nil
    @State private var isNavigating = false
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                HStack {
                    Text("Dashboard")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 10)
                
                ScrollView {
                    VStack(spacing: 25) {
                        chartCardSection
                        recentActivitySection
                    }
                    .padding(.top)
                }
                .background(Color(.systemGroupedBackground))
            }
            .toolbar(.hidden, for: .navigationBar) 
            .navigationDestination(isPresented: $showContriDetail) { ContriView() }
            .navigationDestination(item: $selectedCategoryForNav) { category in
                CategoryDetailView(category: category, transactions: filteredTransactions)
            }
        }
    }
    
    private var chartCardSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Text("Financial Breakdown").font(.headline)
                Spacer()
                Picker("Range", selection: $timeRange) {
                    ForEach(timeRanges, id: \.self) { Text($0) }
                }.pickerStyle(.menu)
            }.padding(.horizontal)
            
            VStack(spacing: 20) {
                ZStack {
                    Chart(chartData, id: \.category) { item in
                        SectorMark(
                            angle: .value("Amount", item.amount),
                            innerRadius: .ratio(0.65),
                            // FIX: Slice grows when tapped
                            outerRadius: poppedCategory == item.category ? .ratio(1.0) : .ratio(0.9),
                            angularInset: 2
                        )
                        .cornerRadius(5)
                        .foregroundStyle(item.color)
                        .opacity(poppedCategory == nil || poppedCategory == item.category ? 1.0 : 0.6)
                    }
                    .frame(width: 260, height: 260) // Force exact square
                    .contentShape(Circle()) // FIX: Ignores corner taps!
                    .chartAngleSelection(value: $rawSelection)
                    .onChange(of: rawSelection) { _, newValue in
                        if let newValue {
                            handleHover(value: newValue)
                        } else {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                                poppedCategory = nil
                            }
                        }
                    }
                    .chartOverlay { proxy in
                        GeometryReader { geo in
                            Rectangle().fill(.clear).contentShape(Rectangle())
                                .onTapGesture { location in
                                    let center = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)
                                    let vector = CGVector(dx: location.x - center.x, dy: location.y - center.y)
                                    var angle = atan2(vector.dy, vector.dx)
                                    
                                    angle += .pi / 2
                                    if angle < 0 { angle += 2 * .pi }
                                    
                                    let total = chartData.reduce(0) { $0 + $1.amount }
                                    let tapValue = (Double(angle) / (2 * .pi)) * total
                                    handleTap(value: tapValue)
                                }
                        }
                    }                    .onChange(of: rawSelection) { _, newValue in
                        if let newValue { handleTap(value: newValue) }
                    }
                    
                    VStack(spacing: 2) {
                        Text("Most Spent").font(.caption).foregroundStyle(.secondary)
                        Text("₹ \(Int(maxExpenseAmount))").font(.largeTitle).fontWeight(.bold)
                    }
                    .frame(width: 150, height: 150)
                    .contentShape(Circle()) // Defines strictly circular deadzone
                    .highPriorityGesture(TapGesture().onEnded { }) // FIX: Swallows center taps!
                }
                
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 10) {
                    ForEach(chartData, id: \.category) { item in
                        HStack(spacing: 4) {
                            Circle().fill(item.color).frame(width: 8, height: 8)
                            Text(item.category).font(.caption).bold()
                        }
                    }
                }
            }
            .padding(.vertical, 20).background(Color(UIColor.secondarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: .black.opacity(0.05), radius: 5).padding(.horizontal)
        }
    }
    
    private var recentActivitySection: some View {
        VStack(alignment: .leading) {
            Text("Recent Activity").font(.headline).padding(.horizontal)
            ForEach(filteredTransactions.prefix(15)) { tx in
                HStack {
                    Circle().fill(tx.color.opacity(0.2)).frame(width: 40, height: 40)
                        .overlay(Image(systemName: "cart.fill").font(.caption).foregroundStyle(tx.color))
                    VStack(alignment: .leading) {
                        Text(tx.category).font(.subheadline).bold()
                        Text(tx.date.formatted(date: .abbreviated, time: .omitted)).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Text("- ₹\(Int(tx.amount))").font(.subheadline).bold()
                }
                .padding().background(Color(UIColor.secondarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 12)).padding(.horizontal)
            }
        }
    }
    
    var filteredTransactions: [Transaction] {
        let cutoffDate: Date
        switch timeRange {
        case "1 Day": cutoffDate = Calendar.current.startOfDay(for: Date())
        case "7 Days": cutoffDate = Calendar.current.date(byAdding: .day, value: -7, to: Date())!
        case "30 Days": cutoffDate = Calendar.current.date(byAdding: .day, value: -30, to: Date())!
        case "12 Months": cutoffDate = Calendar.current.date(byAdding: .year, value: -1, to: Date())!
        default: cutoffDate = Date.distantPast
        }
        return store.transactions.filter { $0.date >= cutoffDate && !$0.isCredit }.sorted { $0.date > $1.date }
    }
    
    var chartData: [(category: String, amount: Double, color: Color)] {
        var data: [(category: String, amount: Double, color: Color)] = []
        let filteredForChart = filteredTransactions.filter { $0.category != "Contri" }
        let grouped = Dictionary(grouping: filteredForChart, by: { $0.category })
        
        for (key, txs) in grouped {
            data.append((category: key, amount: txs.reduce(0) { $0 + $1.amount }, color: txs.first?.color ?? .gray))
        }
        data.append((category: "Contri", amount: store.totalContriAmount, color: .pink))
        return data.sorted { $0.amount > $1.amount }
    }
    
    var maxExpenseAmount: Double { chartData.first?.amount ?? 0 }
    func handleHover(value: Double) {
        var accumulated = 0.0
        for item in chartData {
            if value >= accumulated && value <= (accumulated + item.amount) {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    poppedCategory = item.category
                }
                return
            }
            accumulated += item.amount
        }
    }
    func handleTap(value: Double) {
        guard !isNavigating else { return } // Stop double-taps
        
        var accumulated = 0.0
        for item in chartData {
            if value >= accumulated && value <= (accumulated + item.amount) {
                let cat = item.category
                isNavigating = true
                
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    poppedCategory = cat
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    if cat == "Contri" { showContriDetail = true }
                    else { selectedCategoryForNav = cat }
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        poppedCategory = nil
                        rawSelection = nil
                        isNavigating = false
                    }
                }
                break
            }
            accumulated += item.amount
        }
    }
}

// MARK: - 4. CATEGORY DETAIL VIEW
struct CategoryDetailView: View {
    let category: String
    let transactions: [Transaction]
    
    var body: some View {
        List {
            ForEach(transactions.filter { $0.category == category }) { tx in
                HStack {
                    VStack(alignment: .leading) {
                        Text(tx.date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                        Text(tx.category).font(.headline)
                    }
                    Spacer()
                    Text("₹\(Int(tx.amount))").bold().foregroundStyle(Color.red)
                }
            }
        }
        .navigationTitle("\(category) History")
        .navigationBarTitleDisplayMode(.inline) // Snaps child view to top
    }
}
