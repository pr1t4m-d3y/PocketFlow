import SwiftUI

@main
struct MyApp: App {
    @State private var store = AppDataStore()
    @AppStorage("hasCompletedSetup") private var hasCompletedSetup = false
    
    init() {
        UserDefaults.standard.set(false, forKey: "hasCompletedSetup")
    }
    
    var body: some Scene {
        WindowGroup {
            if hasCompletedSetup {
                ContentView()
                    .environment(store)
            } else {
                OnboardingView()
                    .environment(store)
            }
        }
    }
}
