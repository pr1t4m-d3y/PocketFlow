
import SwiftUI
import Charts

struct ContentView: View {
    @State private var selectedTab = 0
    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView().tabItem { Label("Home", systemImage: "house.fill") }.tag(0)
            HistoryView().tabItem { Label("History", systemImage: "clock.arrow.circlepath") }.tag(1)
            DashboardView().tabItem { Label("Dashboard", systemImage: "chart.pie.fill") }.tag(2)
        }.accentColor(.blue)
    }
}

struct HomeView: View {
    @Environment(AppDataStore.self) private var store
    @Environment(\.scenePhase) private var scenePhase
    
    @State private var inputAmount: String = ""
    @State private var isCredit: Bool = false
    @State private var isExpanded: Bool = false
    @State private var activeTxID: UUID? = nil
    @State private var category: String = "Select Category"
    @State private var note: String = ""
    @State private var showCategoryWarning: Bool = false
    @State private var isContriMode: Bool = false
    @State private var splits: [SplitPerson] = []
    
    @FocusState private var focusedSplitID: UUID?
    @FocusState private var focusedAmountID: UUID?
    
    @State private var backgroundDate: Date? = nil
    let categories = ["Food", "Travel", "Study", "Groceries", "Misc", "Other"]
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                
                HStack {
                    Text("PocketFlow")
                        .font(.system(size: 34, weight: .bold, design: .rounded))
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 10) 
                
                VStack(spacing: 30) {
                    if !isExpanded {
                        VStack {
                            Text("Available Balance").font(.subheadline).foregroundStyle(.secondary)
                            Text("₹ \(Int(store.totalBalance))")
                                .font(.system(size: 44, weight: .bold, design: .rounded))
                                .foregroundStyle(store.totalBalance < 0 ? .red : .primary)
                                .contentTransition(.numericText())
                        }
                        .padding(.vertical, 25).frame(maxWidth: .infinity)
                        .background(Color.blue.opacity(0.1)).clipShape(Capsule()).padding(.horizontal)
                        .transition(.opacity.combined(with: .scale))
                        .padding(.top, 20) // Spacing between App Name and Balance Card
                    }
                    
                    if isExpanded {
                        Button(action: cancelAndEditAmount) {
                            Text("₹ \(inputAmount)")
                                .font(.system(size: 36, weight: .bold, design: .rounded))
                                .padding(.horizontal, 30).padding(.vertical, 12)
                                .background(Color(.systemGray6)).clipShape(Capsule())
                                .foregroundStyle(isCredit ? .green : .red)
                        }.frame(maxWidth: .infinity).transition(.scale.combined(with: .opacity))
                    } else {
                        HStack(spacing: 15) {
                            TextField("0", text: $inputAmount).keyboardType(.decimalPad)
                                .font(.system(size: 24, weight: .semibold)).padding()
                                .background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 15))
                            Picker("Type", selection: $isCredit) {
                                Text("Spend").tag(false)
                                Text("Credit").tag(true)
                            }.pickerStyle(.segmented).frame(width: 120)
                        }.padding(.horizontal).transition(.opacity)
                    }
                    
                    if !isExpanded {
                        Button(action: startLogging) {
                            Text("Log Transaction").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                                .background(isCredit ? Color.green : Color.red).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 15))
                        }.padding(.horizontal).disabled(inputAmount.isEmpty)
                        Spacer()
                    } else {
                        expandedDetailsMenu.transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                }
                .padding(.top, 20)
            }
            // REMOVED: .navigationTitle("PocketFlow") - This was causing the "low" look
            .toolbar(.hidden) // Hides the empty navigation bar space at the top
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: isExpanded)
            .animation(.spring(response: 0.4, dampingFraction: 0.8), value: isContriMode)
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .background { backgroundDate = Date() }
                else if newPhase == .active {
                    if let bgDate = backgroundDate, Date().timeIntervalSince(bgDate) > 30 {
                        if isExpanded { forceReset() }
                    }
                    backgroundDate = nil
                }
            }
            .onTapGesture { UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil) }
            .onChange(of: inputAmount) { old, new in
                if new.count > old.count {
                    playClickSound()
                }
            }
        }
    }
    
    var expandedDetailsMenu: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 15) {
                    HStack {
                        if !isCredit {
                            if !isContriMode {
                                Menu {
                                    ForEach(categories, id: \.self) { cat in
                                        Button(cat) { category = cat; showCategoryWarning = false }
                                    }
                                } label: {
                                    HStack(spacing: 6) {
                                        Image(systemName: category == "Select Category" ? "tag.fill" : "checkmark.circle.fill")
                                        Text(category == "Select Category" ? "Category" : category).lineLimit(1)
                                    }
                                    .font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 14)
                                    .background(showCategoryWarning ? Color.red.opacity(0.15) : Color.blue.opacity(0.1))
                                    .foregroundStyle(showCategoryWarning ? Color.red : Color.blue).clipShape(Capsule())
                                    .overlay(Capsule().stroke(showCategoryWarning ? Color.red : Color.clear, lineWidth: 1.5))
                                }
                            } else {
                                Text("Contri").font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 14)
                                    .background(Color.pink.opacity(0.1)).foregroundStyle(.pink).clipShape(Capsule())
                            }
                        }
                        TextField("Description...", text: $note).padding().background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 15))
                    }
                    
                    if !isCredit {
                        Toggle("Split as Contri", isOn: $isContriMode)
                            .padding(.vertical, 8)
                            .onChange(of: isContriMode) { _, isOn in
                                if isOn {
                                    category = "Contri"
                                    splits = [SplitPerson(amount: 0)]
                                    showCategoryWarning = false
                                } else {
                                    category = "Select Category"; splits = []
                                }
                            }
                        
                        if isContriMode {
                            VStack(spacing: 15) {
                                ForEach($splits) { $split in
                                    HStack {
                                        TextField("Person Name", text: $split.name)
                                            .focused($focusedSplitID, equals: split.id)
                                            .onChange(of: split.name) { _, _ in recalculateSplits() }
                                            .onSubmit { addNewSplitRow() }
                                            .submitLabel(.next)
                                            .padding().background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 10))
                                        
                                        TextField("Amount", value: $split.amount, format: .number)
                                            .keyboardType(.decimalPad)
                                            .focused($focusedAmountID, equals: split.id)
                                            .onChange(of: split.amount) { _, _ in
                                                if focusedAmountID == split.id {
                                                    split.isLocked = true
                                                    recalculateSplits()
                                                }
                                            }
                                            .padding().frame(width: 100).background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 10))
                                    }
                                    .overlay(alignment: .bottomLeading) {
                                        if focusedSplitID == split.id && !split.name.isEmpty {
                                            let matches = store.searchContacts(query: split.name)
                                            if !matches.isEmpty {
                                                ScrollView(.horizontal, showsIndicators: false) {
                                                    HStack {
                                                        ForEach(matches, id: \.name) { contact in
                                                            Button(action: {
                                                                split.name = contact.name
                                                                split.phoneNumber = contact.phone
                                                                focusedSplitID = nil
                                                                recalculateSplits()
                                                                addNewSplitRow()
                                                            }) {
                                                                Text(contact.name).font(.caption).bold().padding(.horizontal, 12).padding(.vertical, 6)
                                                                    .background(Color.blue).foregroundStyle(.white).clipShape(Capsule())
                                                            }
                                                        }
                                                    }
                                                }
                                                .padding(8)
                                                .background(Color(UIColor.systemBackground))
                                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                                .shadow(color: .black.opacity(0.15), radius: 5, x: 0, y: 5)
                                                .offset(y: -50)
                                            }
                                        }
                                    }
                                    .zIndex(focusedSplitID == split.id ? 1 : 0)
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.top, 10)
                .padding(.bottom, 20)
            }
            .scrollIndicators(.hidden)
            .frame(maxHeight: .infinity)
            
            Spacer(minLength: 10)
            Button(action: finalizeAndReset) {
                Text("Done").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                    .background(Color.blue).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 15))
            }.padding()
        }
    }
    
    func startLogging() {
        guard let amt = Double(inputAmount) else { return }
        triggerImpactHaptic(style: .medium)
        if isCredit { note = "Pocket Money"; category = "Income" }
        store.requestPermissions()
        var newTx = Transaction(category: isCredit ? "Income" : "Select Category", amount: amt, date: Date(), isCredit: isCredit)
        if !isCredit { newTx.notificationID = store.scheduleReminder(amount: amt) }
        store.addTransaction(newTx)
        activeTxID = newTx.id
        isExpanded = true
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    func cancelAndEditAmount() {
        if let id = activeTxID {
            let tx = store.transactions.first(where: { $0.id == id })
            store.cancelReminder(id: tx?.notificationID)
            store.transactions.removeAll { $0.id == id }
        }
        withAnimation { isExpanded = false; activeTxID = nil; if isCredit { note = "" } }
    }
    
    func addNewSplitRow() {
        let newSplit = SplitPerson(amount: 0)
        splits.append(newSplit)
        recalculateSplits()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { focusedSplitID = newSplit.id }
    }
    
    func recalculateSplits() {
        let total = Double(inputAmount) ?? 0
        let activeSplits = splits.filter { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty || $0.isLocked }
        let lockedSum = activeSplits.filter { $0.isLocked }.reduce(0) { $0 + $1.amount }
        let unlockedCount = activeSplits.filter { !$0.isLocked }.count
        
        let remaining = max(total - lockedSum, 0)
        let autoSplitAmount = unlockedCount > 0 ? (remaining / Double(unlockedCount + 1)) : 0
        
        for i in 0..<splits.count {
            if !splits[i].isLocked {
                if !splits[i].name.trimmingCharacters(in: .whitespaces).isEmpty {
                    splits[i].amount = autoSplitAmount
                } else {
                    splits[i].amount = 0
                }
            }
        }
    }
    
    func finalizeAndReset() {
        if !isCredit && !isContriMode && category == "Select Category" {
            triggerWarningHaptic()
            withAnimation { showCategoryWarning = true }
            return
        }
        triggerSuccessHaptic()
        
        if let id = activeTxID {
            if note != "" || category != "Select Category" {
                let tx = store.transactions.first(where: { $0.id == id })
                store.cancelReminder(id: tx?.notificationID)
            }
            
            let validSplits = splits.filter { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty }
            let finalNote = note
            
            store.updateTransaction(id: id, category: category, note: finalNote, splits: validSplits)
            
            if !isCredit && isContriMode {
                for split in validSplits {
                    store.addFriendDebt(name: split.name, phoneNumber: split.phoneNumber, amount: split.amount, date: Date(), note: finalNote)
                }
            }
        }
        
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        withAnimation { isExpanded = false }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            inputAmount = ""; note = ""; isContriMode = false; activeTxID = nil; splits = []; category = "Select Category"; showCategoryWarning = false; isCredit = false
        }
    }
    
    func forceReset() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        withAnimation { isExpanded = false }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            inputAmount = ""; note = ""; isContriMode = false; activeTxID = nil; splits = []; category = "Select Category"; showCategoryWarning = false; isCredit = false
        }
    }
}






struct ContriView: View {
    @Environment(AppDataStore.self) private var store
    @State private var rawSelection: Double? = nil
    @State private var selectedFriend: Friend? = nil
    
    // NEW: Animation & Safety States
    @State private var poppedFriendID: UUID? = nil
    @State private var isNavigating = false
    
    var topFriends: [Friend] {
        Array(store.friends.sorted(by: { $0.totalOwed > $1.totalOwed }).prefix(5))
    }
    
    var allFriendsSorted: [Friend] {
        store.friends.sorted(by: { $0.totalOwed > $1.totalOwed })
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                chartSection
                friendsListSection
                Spacer()
            }
            .padding(.top)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle("Contributions")
        .navigationBarTitleDisplayMode(.inline)
        .navigationDestination(item: $selectedFriend) { friend in
            FriendDetailView(friendID: friend.id)
        }
    }
    
    private var friendsListSection: some View {
        VStack(spacing: 0) {
            ForEach(allFriendsSorted) { friend in
                Button(action: { selectedFriend = friend }) {
                    HStack {
                        Text(friend.name).fontWeight(.semibold)
                        Spacer()
                        Text("₹\(Int(friend.totalOwed))").fontWeight(.bold)
                        Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                    }
                    .padding().foregroundStyle(.primary)
                }
                Divider().padding(.leading)
            }
        }
        .background(Color(UIColor.secondarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 12)).padding(.horizontal)
    }
    
    private var chartSection: some View {
        VStack(alignment: .leading, spacing: 15) {
            Text("Top 5 Owed to You").font(.headline).padding(.horizontal)
            
            VStack(spacing: 20) {
                ZStack {
                    Chart(topFriends, id: \.name) { item in
                        SectorMark(
                            angle: .value("Amount", item.totalOwed),
                            innerRadius: .ratio(0.65),
                            // FIX: Slice grows when tapped
                            outerRadius: poppedFriendID == item.id ? .ratio(1.0) : .ratio(0.9),
                            angularInset: 2
                        )
                        .cornerRadius(5)
                        .foregroundStyle(item.color)
                        // FIX: Dims other slices
                        .opacity(poppedFriendID == nil || poppedFriendID == item.id ? 1.0 : 0.6)
                    }
                    .frame(width: 260, height: 260)
                    .contentShape(Circle()) // FIX: Ignores corner taps
                    .chartOverlay { proxy in
                        GeometryReader { geo in
                            Rectangle().fill(.clear).contentShape(Rectangle())
                                .onTapGesture { location in
                                    let center = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)
                                    let vector = CGVector(dx: location.x - center.x, dy: location.y - center.y)
                                    var angle = atan2(vector.dy, vector.dx)
                                    
                                    angle += .pi / 2
                                    if angle < 0 { angle += 2 * .pi }
                                    
                                    let total = topFriends.reduce(0) { $0 + $1.totalOwed }
                                    let tapValue = (Double(angle) / (2 * .pi)) * total
                                    handleTap(value: tapValue)
                                }
                        }
                    }
                    .chartAngleSelection(value: $rawSelection)
                    .onChange(of: rawSelection) { _, newValue in
                        if let newValue {
                            handleHover(value: newValue)
                        } else {
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                                poppedFriendID = nil
                            }
                        }
                    }
                    
                    VStack(spacing: 2) {
                        Text("Highest Due").font(.caption).foregroundStyle(.secondary)
                        Text("₹ \(Int(topFriends.first?.totalOwed ?? 0))")
                            .font(.largeTitle).fontWeight(.bold)
                    }
                    .frame(width: 150, height: 150)
                    .contentShape(Circle())
                    .highPriorityGesture(TapGesture().onEnded { }) // FIX: Swallows center taps
                }
                
                legendGrid
            }
            .padding(.vertical, 20).background(Color(UIColor.secondarySystemGroupedBackground)).clipShape(RoundedRectangle(cornerRadius: 16))
            .shadow(color: .black.opacity(0.05), radius: 5).padding(.horizontal)
        }
    }
    
    private var legendGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), alignment: .leading), GridItem(.flexible(), alignment: .leading)], spacing: 10) {
            ForEach(topFriends) { friend in
                HStack(spacing: 6) {
                    Circle().fill(friend.color).frame(width: 8, height: 8)
                    Text(friend.name).font(.caption).fontWeight(.medium)
                }
            }
        }
        .padding(.horizontal)
    }
    func handleHover(value: Double) {
        var accumulated = 0.0
        for friend in topFriends {
            let sliceSize = friend.totalOwed
            let endRange = accumulated + sliceSize
            if value >= accumulated && value <= endRange {
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    poppedFriendID = friend.id
                }
                return
            }
            accumulated = endRange
        }
    }
    func handleTap(value: Double) {
        guard !isNavigating else { return }
        
        var accumulated = 0.0
        for friend in topFriends {
            let sliceSize = friend.totalOwed
            let endRange = accumulated + sliceSize
            if value >= accumulated && value <= endRange {
                isNavigating = true
                
                withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                    poppedFriendID = friend.id
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    selectedFriend = friend
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        poppedFriendID = nil
                        rawSelection = nil
                        isNavigating = false
                    }
                }
                return
            }
            accumulated = endRange
        }
    }
}

// MARK: - FRIEND DETAIL VIEW
struct FriendDetailView: View {
    @Environment(AppDataStore.self) private var store
    let friendID: UUID
    
    @State private var showPaymentSheet = false
    @State private var paymentAmountString = ""
    
    var currentFriend: Friend? {
        store.friends.first(where: { $0.id == friendID })
    }
    
    var body: some View {
        if let friend = currentFriend {
            VStack {
                VStack(spacing: 5) {
                    Text("Total Outstanding").font(.subheadline).foregroundStyle(.secondary)
                    Text("₹ \(Int(friend.totalOwed))")
                        .font(.system(size: 44, weight: .bold, design: .rounded))
                        .foregroundStyle(friend.totalOwed > 0 ? .red : .green)
                        .contentTransition(.numericText())
                }.padding(.vertical, 30)
                
                List {
                    Section(header: Text("Transaction History")) {
                        ForEach(friend.history.sorted(by: { $0.date > $1.date })) { tx in
                            HStack {
                                VStack(alignment: .leading) {
                                    Text(tx.note.isEmpty ? (tx.type == .debt ? "Added Debt" : "Payment Received") : tx.note).font(.headline)
                                    Text(tx.date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(tx.type == .debt ? "₹\(Int(tx.amount))" : "- ₹\(Int(tx.amount))")
                                    .fontWeight(.bold).foregroundStyle(tx.type == .debt ? .red : .green)
                            }
                        }
                    }
                }.listStyle(.insetGrouped)
                
                Button(action: { showPaymentSheet = true }) {
                    HStack {
                        Image(systemName: "banknote.fill")
                        Text("Record Payment")
                    }
                    .font(.headline).foregroundStyle(.white).frame(maxWidth: .infinity).padding()
                    .background(Color.blue).clipShape(RoundedRectangle(cornerRadius: 15)).padding()
                }
            }
            .navigationTitle(friend.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if let phone = friend.phoneNumber, let url = URL(string: "tel://\(phone.replacingOccurrences(of: " ", with: ""))") {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Link(destination: url) {
                            Image(systemName: "phone.circle.fill").font(.title2).foregroundStyle(.green)
                        }
                    }
                }
            }
            .sheet(isPresented: $showPaymentSheet) {
                VStack(spacing: 20) {
                    Text("Payment from \(friend.name)").font(.headline).padding(.top)
                    TextField("Amount", text: $paymentAmountString)
                        .keyboardType(.decimalPad).font(.title.bold()).multilineTextAlignment(.center).padding()
                        .background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 12)).padding(.horizontal)
                    
                    Button(action: savePayment) {
                        Text("Confirm Payment").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                            .background(Color.green).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 12))
                    }.padding(.horizontal).disabled(paymentAmountString.isEmpty)
                    Spacer()
                }.presentationDetents([.height(300)])
            }
        }
    }
    
    func savePayment() {
        guard let amount = Double(paymentAmountString),
              let index = store.friends.firstIndex(where: { $0.id == friendID }) else { return }
        
        let friendName = store.friends[index].name
        
        // 1. Update the friend's personal debt history
        let newTransaction = FriendTransaction(date: Date(), amount: amount, type: .payment, note: "Paid Back")
        store.friends[index].history.append(newTransaction)
        store.friends[index].totalOwed -= amount
        
        // 2. NEW: Log it as an Income transaction so your global balance increases
        let globalTx = Transaction(
            category: "Income",
            amount: amount,
            date: Date(),
            isCredit: true,
            note: "\(friendName) paid back"
        )
        store.addTransaction(globalTx)
        
        paymentAmountString = ""
        showPaymentSheet = false
        
    }
}

