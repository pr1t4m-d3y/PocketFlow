import SwiftUI

struct OnboardingView: View {
    @Environment(AppDataStore.self) private var store
    @AppStorage("hasCompletedSetup") private var hasCompletedSetup = false
    
    @State private var balanceInput: String = ""
    
    var body: some View {
        VStack(spacing: 40) {
            // Top Option: Demo Data
            Button(action: {
                store.setupAccount(initialBalance: nil, useDemoData: true)
                withAnimation { hasCompletedSetup = true }
            }) {
                Text("Continue with Demo Data")
                    .font(.subheadline).bold()
                    .foregroundStyle(.blue)
            }
            .padding(.top, 20)

            Spacer()

            VStack(spacing: 20) {
                Image(systemName: "tray.and.arrow.down.fill")
                    .font(.system(size: 80))
                    .foregroundStyle(.blue)
                
                Text("Welcome to PocketFlow")
                    .font(.largeTitle).bold()
                
                Text("Enter your current bank balance to get started.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
                    .onChange(of: balanceInput) { old, new in
                                if new.count > old.count {
                                    playClickSound()
                                }
                            }
            }

            // Custom Balance Input
            TextField("₹ 0", text: $balanceInput)
                .keyboardType(.decimalPad)
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .multilineTextAlignment(.center)
                .padding()
                .background(Color(.systemGray6))
                .clipShape(RoundedRectangle(cornerRadius: 20))
                .padding(.horizontal, 50)

            Button(action: {
                triggerSuccessHaptic()
                let amount = Double(balanceInput) ?? 0
                store.setupAccount(initialBalance: amount, useDemoData: false)
                withAnimation { hasCompletedSetup = true }
            }) {
                Text("Set Initial Balance")
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(balanceInput.isEmpty ? Color.gray : Color.blue)
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
            }
            .disabled(balanceInput.isEmpty)
            .padding(.horizontal, 40)

            Spacer()
        }
    }
}
