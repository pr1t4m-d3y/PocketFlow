// MARK: - 2. HISTORY VIEW
import SwiftUI
struct HistoryView: View {
    @Environment(AppDataStore.self) private var store
    @State private var editingTx: Transaction? = nil
    
    var body: some View {
            NavigationStack {
                VStack(spacing: 0) {
                    HStack {
                        Text("History")
                            .font(.system(size: 34, weight: .bold, design: .rounded))
                        Spacer()
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    List {
                        ForEach(store.transactions.sorted(by: { $0.date > $1.date })) { tx in
                            HStack {
                                Image(systemName: tx.isCredit ? "arrow.up.circle.fill" : "arrow.down.circle.fill")
                                    .foregroundStyle(tx.isCredit ? .green : .red).font(.title2)
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("₹ \(Int(tx.amount))").font(.headline).fontWeight(.bold)
                                    HStack(spacing: 4) {
                                        Text(tx.category).font(.subheadline).foregroundStyle(.secondary)
                                        
                                        if tx.isDescriptionPending {
                                            Text("• Pending").font(.caption).bold().foregroundStyle(.orange)
                                        } else {
                                            Text("• \(tx.note)").font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                        }
                                    }
                                }
                                Spacer()
                                Text(tx.date.formatted(date: .abbreviated, time: .shortened)).font(.caption).foregroundStyle(.secondary)
                            }
                            .contentShape(Rectangle())
                            .onTapGesture {
                                editingTx = tx
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                }
                .toolbar(.hidden, for: .navigationBar)
            }
            .sheet(item: $editingTx) { tx in
                EditTransactionSheet(tx: tx)
            }
        }
}

// MARK: - 2.5 ISOLATED EDIT SHEET (Fixes All Keyboard & Focus Bugs)
struct EditTransactionSheet: View {
    @Environment(AppDataStore.self) private var store
    @Environment(\.dismiss) private var dismiss
    
    let tx: Transaction
    
    @State private var editCategory: String
    @State private var editNote: String
    @State private var showCategoryWarning: Bool = false
    @State private var isContriMode: Bool
    @State private var splits: [SplitPerson]
    @State private var isEstablishedContri: Bool
    
    @FocusState private var focusedSplitID: UUID?
    @FocusState private var focusedAmountID: UUID?
    
    let categories = ["Food", "Travel", "Study", "Groceries", "Misc", "Other"]
    
    init(tx: Transaction) {
        self.tx = tx
        _editCategory = State(initialValue: tx.category)
        _editNote = State(initialValue: tx.note)
        
        let isContri = (tx.category == "Contri")
        _isContriMode = State(initialValue: isContri)
        
        let established = isContri && !tx.splits.isEmpty
        _isEstablishedContri = State(initialValue: established)
        
        var initialSplits = tx.splits
        if isContri {
            if initialSplits.isEmpty {
                initialSplits.append(SplitPerson(amount: 0))
            } else if let last = initialSplits.last, !last.name.trimmingCharacters(in: .whitespaces).isEmpty {
                initialSplits.append(SplitPerson(amount: 0))
            }
        }
        _splits = State(initialValue: initialSplits)
    }
    
    var body: some View {
        VStack(spacing: 0) {
            Text(isEstablishedContri ? "Review Split" : (tx.isCredit ? "Edit Income" : "Edit Expense"))
                .font(.headline)
                .padding(.top, 25)
                .padding(.bottom, 15)
            
            ScrollView {
                VStack(spacing: 15) {
                    HStack {
                        if !tx.isCredit {
                            if !isContriMode {
                                Menu {
                                    ForEach(categories, id: \.self) { cat in
                                        Button(cat) { editCategory = cat; showCategoryWarning = false }
                                    }
                                } label: {
                                    HStack(spacing: 6) {
                                        Image(systemName: editCategory == "Select Category" ? "tag.fill" : "checkmark.circle.fill")
                                        Text(editCategory == "Select Category" ? "Category" : editCategory).lineLimit(1)
                                    }
                                    .font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 14)
                                    .background(showCategoryWarning ? Color.red.opacity(0.15) : Color.blue.opacity(0.1))
                                    .foregroundStyle(showCategoryWarning ? Color.red : Color.blue).clipShape(Capsule())
                                    .overlay(Capsule().stroke(showCategoryWarning ? Color.red : Color.clear, lineWidth: 1.5))
                                }
                            } else {
                                Text("Contri").font(.subheadline.bold()).padding(.horizontal, 16).padding(.vertical, 14)
                                    .background(Color.pink.opacity(0.1)).foregroundStyle(.pink).clipShape(Capsule())
                            }
                        }
                        TextField("Description...", text: $editNote).padding().background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 15))
                    }
                    
                    if !tx.isCredit && !isEstablishedContri {
                        Toggle("Split as Contri", isOn: $isContriMode)
                            .padding(.vertical, 8)
                            .onChange(of: isContriMode) { _, isOn in
                                if isOn {
                                    editCategory = "Contri"
                                    if splits.isEmpty { splits = [SplitPerson(amount: 0)] }
                                    showCategoryWarning = false
                                }
                                else { editCategory = "Select Category"; splits = [] }
                            }
                    }
                    
                    if isContriMode {
                        VStack(spacing: 15) {
                            ForEach($splits) { $split in
                                VStack(spacing: 8) {
                                    HStack {
                                        TextField("Person Name", text: $split.name)
                                            .focused($focusedSplitID, equals: split.id)
                                            .onChange(of: split.name) { _, _ in recalculateSplits(total: tx.amount) }
                                            .onSubmit { addNewSplitRow(total: tx.amount) }
                                            .submitLabel(.next)
                                            .padding().background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 10))
                                        
                                        TextField("Amount", value: $split.amount, format: .number)
                                            .keyboardType(.decimalPad)
                                            .focused($focusedAmountID, equals: split.id)
                                            .onChange(of: split.amount) { _, _ in
                                                if focusedAmountID == split.id { split.isLocked = true; recalculateSplits(total: tx.amount) }
                                            }
                                            .padding().frame(width: 100).background(Color(.systemGray6)).clipShape(RoundedRectangle(cornerRadius: 10))
                                    }
                                    
                                    if focusedSplitID == split.id && !split.name.isEmpty {
                                        let matches = store.searchContacts(query: split.name)
                                        if !matches.isEmpty {
                                            ScrollView(.horizontal, showsIndicators: false) {
                                                HStack {
                                                    ForEach(matches, id: \.name) { contact in
                                                        Button(action: {
                                                            split.name = contact.name
                                                            split.phoneNumber = contact.phone
                                                            focusedSplitID = nil
                                                            recalculateSplits(total: tx.amount)
                                                            addNewSplitRow(total: tx.amount)
                                                        }) {
                                                            Text(contact.name).font(.caption).bold().padding(.horizontal, 12).padding(.vertical, 6)
                                                                .background(Color.blue.opacity(0.15)).foregroundStyle(.blue).clipShape(Capsule())
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
            .scrollIndicators(.hidden)
            
            Spacer(minLength: 10)
            Button(action: {
                triggerSuccessHaptic()
                if !tx.isCredit && !isContriMode && editCategory == "Select Category" {
                    triggerWarningHaptic()
                    withAnimation { showCategoryWarning = true }; return }
                
                store.cancelReminder(id: tx.notificationID)
                let validSplits = splits.filter { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty }
                let wasAlreadyContri = (tx.category == "Contri")
                
                let finalNote = editNote
                
                store.updateTransaction(id: tx.id, category: editCategory, note: finalNote, splits: validSplits)
                
                if !tx.isCredit && isContriMode && !wasAlreadyContri {
                    for split in validSplits { store.addFriendDebt(name: split.name, phoneNumber: split.phoneNumber, amount: split.amount, date: tx.date, note: finalNote) }
                }
                dismiss()
            }) {
                Text("Save").fontWeight(.bold).frame(maxWidth: .infinity).padding()
                    .background(Color.blue).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 15))
            }
            .padding(.horizontal)
            .padding(.bottom, 20)
        }
        .presentationDetents(isEstablishedContri || isContriMode ? [.medium, .large] : [.height(280)])
    }
    
    func addNewSplitRow(total: Double) {
        let newSplit = SplitPerson(amount: 0)
        splits.append(newSplit)
        recalculateSplits(total: total)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { focusedSplitID = newSplit.id }
    }
    
    func recalculateSplits(total: Double) {
        let activeSplits = splits.filter { !$0.name.trimmingCharacters(in: .whitespaces).isEmpty || $0.isLocked }
        let lockedSum = activeSplits.filter { $0.isLocked }.reduce(0) { $0 + $1.amount }
        let unlockedCount = activeSplits.filter { !$0.isLocked }.count
        
        let remaining = max(total - lockedSum, 0)
        let autoSplitAmount = unlockedCount > 0 ? (remaining / Double(unlockedCount + 1)) : 0
        
        for i in 0..<splits.count {
            if !splits[i].isLocked {
                if !splits[i].name.trimmingCharacters(in: .whitespaces).isEmpty {
                    splits[i].amount = autoSplitAmount
                } else {
                    splits[i].amount = 0
                }
            }
        }
    }
}
